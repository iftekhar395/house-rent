package com.example.myhouse;


import com.example.myhouse.model.Rent;
import com.example.myhouse.model.User;

public class Availablity {

    public static User currentUser;
    public static Rent currentRent;
}
