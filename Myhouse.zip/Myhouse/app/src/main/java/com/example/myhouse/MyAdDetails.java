package com.example.myhouse;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.myhouse.firebase.FirebaseHandler;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.annotations.Nullable;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;

import java.util.HashMap;
import java.util.Map;
public class MyAdDetails extends AppCompatActivity {

    private EditText tvMyPostTitle;
    private EditText tvMyLocation;
    private ImageView ivMyPostImage;
    private EditText tvMyPostHousePrice;
    private Spinner tvMyPostPeriod;
    private EditText tvMyAddress;
    private EditText tvMyPostDescription;
    private EditText tvMyNumOfBeds;
    private EditText tvMyNumOfBaths, tvMyNumOfToilets, tvMyNumOfBalconies;
    private EditText tvMyContact;
    private TextView tvMyEmail;
    private Button btnMyLocation, btnUpdate, btnDelete;
    private static final int CAMERA_REQUEST_CODE = 200;
    private static final int STORAGE_REQUEST_CODE = 300;
    private static final int IMAGE_PICK_GALLERY_CODE = 400;
    private static final int IMAGE_PICK_CAMERA_CODE = 500;
    private String[] cameraPermissions;
    private String[] storagePermissions;
    private Uri image_uri;

    private DatabaseReference rentDatabase;

    private String selectedKey;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_ad_details);

        rentDatabase = new FirebaseHandler().getFirebaseConnection("Rent");

        tvMyPostTitle = findViewById(R.id.tvMyPostTitle);
        tvMyLocation = findViewById(R.id.tvMyLocation);
        ivMyPostImage = findViewById(R.id.ivMyPostImage);
        tvMyPostHousePrice = findViewById(R.id.tvMyPostHousePrice);
        tvMyAddress = findViewById(R.id.tvMyAddress);
        tvMyPostPeriod = findViewById(R.id.tvMyPostPeriod);
        tvMyPostDescription = findViewById(R.id.tvMyPostDescription);
        tvMyNumOfBeds = findViewById(R.id.tvMyNumOfBeds);
        tvMyNumOfBaths = findViewById(R.id.tvMyNumOfBaths);
        tvMyNumOfToilets = findViewById(R.id.tvMyNumOfToilets);
        tvMyNumOfBalconies = findViewById(R.id.tvMyNumOfBalconies);
        tvMyContact = findViewById(R.id.tvMyContact);
        tvMyEmail = findViewById(R.id.tvMyEmail);
        btnMyLocation = findViewById(R.id.btnMyLocation);
        btnUpdate = findViewById(R.id.btnUpdate);


        ivMyPostImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showImagePickDialog();
                ;
            }
        });
//        btnUpdate.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//
//            }
//        });
//
//        btnDelete.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                final StorageReference storageReference = FirebaseStorage.getInstance().getReference("house_image/"+selectedKey);
//                rentDatabase.child(selectedKey).removeValue().addOnSuccessListener(new OnSuccessListener<Void>() {
//                    @Override
//                    public void onSuccess(Void aVoid) {
//                        storageReference.delete().addOnSuccessListener(new OnSuccessListener<Void>() {
//                            @Override
//                            public void onSuccess(Void aVoid) {
//                                Toast.makeText(MyAdDetails.this,"Successfully deleted",Toast.LENGTH_LONG).show();
//                            }
//                        });
//                    }
//                });
//            }
//        });

        ivMyPostImage.setImageResource(R.drawable.ic_for_rent_signage);


        Bundle bundle = getIntent().getExtras();

        String title = bundle.getString("title");
        String postBy = bundle.getString("postBy");
        String date = bundle.getString("date");
        String location = bundle.getString("location");
        String fee = bundle.getString("fee");
        String period = bundle.getString("period");
        final String address = bundle.getString("address");
        String description = bundle.getString("description");
        int numBeds = bundle.getInt("beds");
        int numBaths = bundle.getInt("baths");
        int numToilets = bundle.getInt("toilets");
        int numBalconies = bundle.getInt("balconies");
        final String contact = bundle.getString("contact");
        String email = bundle.getString("email");
        selectedKey = bundle.getString("key");

        tvMyPostTitle.setText(title);
        tvMyLocation.setText(location);
        tvMyPostHousePrice.setText(fee);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.period, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        tvMyPostPeriod.setAdapter(adapter);
        if (period != null) {
            if (period.equals("month")) {
                tvMyPostPeriod.setSelection(adapter.getPosition("Monthly"));
            } else {
                tvMyPostPeriod.setSelection(adapter.getPosition("Yearly"));
            }
        }

        tvMyAddress.setText(address);
        tvMyPostDescription.setText(description);
        tvMyNumOfBeds.setText(numBeds + "");
        tvMyNumOfBaths.setText(numBaths + "");
        tvMyNumOfToilets.setText(numToilets + "");
        tvMyNumOfBalconies.setText(numBalconies + "");
        tvMyContact.setText(contact);
        tvMyEmail.setText(email);

        btnMyLocation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + address)));
            }
        });


        if (selectedKey != null) {
            StorageReference storageReference = FirebaseStorage.getInstance().getReference("house_image/" + selectedKey);
            if (storageReference != null) {
                storageReference.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                    @Override
                    public void onSuccess(Uri uri) {
                        Picasso.get().load(uri).into(ivMyPostImage);
                    }
                });
            }
        } else {
            Toast.makeText(MyAdDetails.this, "Image_key not found", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = new MenuInflater(MyAdDetails.this);
        inflater.inflate(R.menu.edit_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.menuEditPost) {
            rentDatabase.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    Map<String, Object> rentChildUpdates = new HashMap<>();
                    rentChildUpdates.put("address", tvMyAddress.getText().toString().trim());
                    rentChildUpdates.put("contact", tvMyContact.getText().toString().trim());
                    rentChildUpdates.put("description", tvMyPostDescription.getText().toString().trim());
                    rentChildUpdates.put("fee", tvMyPostHousePrice.getText().toString().trim());
                    rentChildUpdates.put("location", tvMyLocation.getText().toString().trim());
                    rentChildUpdates.put("numOfBaths", Integer.parseInt(tvMyNumOfBaths.getText().toString()));
                    rentChildUpdates.put("numOfBeds", Integer.parseInt(tvMyNumOfBeds.getText().toString()));
                    rentChildUpdates.put("numOfToilets", Integer.parseInt(tvMyNumOfToilets.getText().toString()));
                    rentChildUpdates.put("numOfBalconies", Integer.parseInt(tvMyNumOfBalconies.getText().toString()));
                    if (tvMyPostPeriod.getSelectedItem().toString().equals("Monthly")) {
                        rentChildUpdates.put("period", "month");
                    } else {
                        rentChildUpdates.put("period", "year");
                    }
                    rentChildUpdates.put("title", tvMyPostTitle.getText().toString().trim());

                    rentDatabase.child(selectedKey).updateChildren(rentChildUpdates);
                    new AlertDialog.Builder(MyAdDetails.this).setTitle("Success").setMessage("Updated successfully!").show();
                    startActivity(new Intent(MyAdDetails.this, MyPosts.class));
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });
        } else if (item.getItemId() == R.id.menuDeletePost) {
            new AlertDialog.Builder(MyAdDetails.this)
                    .setTitle("Warning")
                    .setMessage("Do you really want to Delete this post?")
                    .setIcon(android.R.drawable.ic_dialog_alert)
                    .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {

                        public void onClick(DialogInterface dialog, int whichButton) {

                            Query rentsQuery = rentDatabase.child(selectedKey);
                            rentsQuery.addListenerForSingleValueEvent(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                    for (DataSnapshot rentSnapshot : dataSnapshot.getChildren()) {
                                        rentSnapshot.getRef().removeValue();
                                    }
                                    new AlertDialog.Builder(MyAdDetails.this)
                                            .setTitle("Success")
                                            .setMessage("Post has been deleted!")
                                            .setIcon(R.drawable.ic_done_black_24dp)
                                            .show();
                                    startActivity(new Intent(MyAdDetails.this, MyPosts.class));
                                }

                                @Override
                                public void onCancelled(@NonNull DatabaseError databaseError) {

                                }
                            });
                        }
                    })
                    .setNegativeButton(android.R.string.no, null).show();
        }
        return true;
    }

    private void showImagePickDialog() {
        String[] options = {"Camera", "Gallery"};
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Pick the Image")
                .setItems(options, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        if (i == 0) {
                            //camera clicked
                            if (checkCameraPermission()) {
                                //permission allowed
                                pickFromCamera();
                            } else {
                                //not allowed
                                requestCameraPermission();
                            }
                        } else {
                            //gallery clicked
                            if (checkStoragePermission()) {
                                //permission allowed
                                pickFromGallery();

                            } else {
                                //not allowed
                                requestStoragePermission();
                            }
                        }
                    }
                })
                .show();
    }

    private void pickFromGallery() {
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType("image/*");
        startActivityForResult(intent, IMAGE_PICK_GALLERY_CODE);
    }

    private void pickFromCamera() {
        ContentValues contentValues = new ContentValues();
        contentValues.put(MediaStore.Images.Media.TITLE, "Temp_Image Title");
        contentValues.put(MediaStore.Images.Media.DESCRIPTION, "Temp_Image Description");
        image_uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues);
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        intent.putExtra(MediaStore.EXTRA_OUTPUT, image_uri);
        startActivityForResult(intent, IMAGE_PICK_CAMERA_CODE);
    }

    private boolean checkCameraPermission() {
        boolean result = ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) ==
                (PackageManager.PERMISSION_GRANTED);
        boolean result1 = ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) ==
                (PackageManager.PERMISSION_GRANTED);
        return result && result1;
    }

    private boolean checkStoragePermission() {
        boolean result = ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) ==
                (PackageManager.PERMISSION_GRANTED);
        return result;
    }

    private void requestStoragePermission() {
        ActivityCompat.requestPermissions(this, storagePermissions, STORAGE_REQUEST_CODE);
    }

    private void requestCameraPermission() {
        ActivityCompat.requestPermissions(this, cameraPermissions, CAMERA_REQUEST_CODE);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        switch (requestCode) {
            case CAMERA_REQUEST_CODE: {
                if (grantResults.length > 0) {
                    boolean cameraAccepted = grantResults[0] == PackageManager.PERMISSION_GRANTED;
                    boolean storageAccepted = grantResults[1] == PackageManager.PERMISSION_GRANTED;
                    if (cameraAccepted && storageAccepted) {
                        pickFromCamera();
                    } else {
                        Toast.makeText(this, "Camera Permission is Needed....", Toast.LENGTH_LONG).show();
                    }
                }
            }
            break;
            case STORAGE_REQUEST_CODE: {
                if (grantResults.length > 0) {
                    boolean storageAccepted = grantResults[0] == PackageManager.PERMISSION_GRANTED;
                    if (storageAccepted) {
                        pickFromGallery();
                    } else {
                        Toast.makeText(this, "Storage Permission Needed....", Toast.LENGTH_LONG).show();
                    }
                }
            }
            break;
        }

        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {

        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            if (requestCode == IMAGE_PICK_GALLERY_CODE) {
                image_uri = data.getData();
                ivMyPostImage.setImageURI(image_uri);
            } else if (requestCode == IMAGE_PICK_CAMERA_CODE) {
//                image_uri = data.getData();
                ivMyPostImage.setImageURI(image_uri);
            }
        }

        if (image_uri != null) {
            StorageReference storageReference = FirebaseStorage.getInstance().getReference("house_image/"+selectedKey);
//                    if(image_uri!=null){
            storageReference.putFile(image_uri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                @Override
                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                    Toast.makeText(MyAdDetails.this, "Picture updated successfully", Toast.LENGTH_SHORT).show();
                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    Toast.makeText(MyAdDetails.this, "Picture upload failed", Toast.LENGTH_SHORT).show();
                }
            });


        }

    }
//    @Override
//    public void onBackPressed() {
//        super.onBackPressed();
//        finish();
//        Intent intent = new Intent(MyAdDetails.this,HomeActivity.class);
//        startActivity(intent);
//    }
}