package com.example.myhouse;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.ContentValues;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.app.DatePickerDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.myhouse.firebase.FirebaseHandler;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.annotations.Nullable;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;
public class Profile extends AppCompatActivity {


    private ImageView imageView;
    private static final int CAMERA_REQUEST_CODE = 200;
    private static final int STORAGE_REQUEST_CODE = 300;
    private static final int IMAGE_PICK_GALLERY_CODE = 400;
    private static final int IMAGE_PICK_CAMERA_CODE = 500;
    //permission arrays
    //private String [] locationPermissions;
    private String[] cameraPermissions;
    private String[] storagePermissions;
    private Uri image_uri;


    private ProgressDialog pDialog;
    private TextView tvProfileUserRole;
    private TextView tvProfileUserName;
    private EditText tvProfileEmail;
    private EditText tvProfileFullName;
    private EditText tvProfileContact;
    private TextView tvProfileGender;
    private TextView tvProfileDateOfBirth;
    private EditText tvProfileAddress;

    private Button btnUpdate;
    private Button btnDeleteAccount;

    private String USER_TABLE = "User";
    private String RENT_TABLE = "Rent";
    private DatabaseReference userDatabase;
    private DatabaseReference rentDatabase;

    @Override
    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        userDatabase = new FirebaseHandler().getFirebaseConnection(USER_TABLE);
        rentDatabase = new FirebaseHandler().getFirebaseConnection(RENT_TABLE);

        tvProfileUserRole = findViewById(R.id.tvProfileUserRole);
        tvProfileUserName = findViewById(R.id.tvProfileUserName);
        tvProfileEmail = findViewById(R.id.tvProfileEmail);
        tvProfileFullName = findViewById(R.id.tvProfileFullName);
        tvProfileContact = findViewById(R.id.tvProfileContact);
        tvProfileGender = findViewById(R.id.tvProfileGender);
        tvProfileDateOfBirth = findViewById(R.id.tvProfileDateOfBirth);
        tvProfileAddress = findViewById(R.id.tvProfileAddress);


        imageView = findViewById(R.id.imageView);
        StorageReference storageReference = FirebaseStorage.getInstance().getReference(Availablity.currentUser.getUserName());
        if (storageReference != null) {
            storageReference.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                @Override
                public void onSuccess(Uri uri) {
                    Picasso.get().load(uri).into(imageView);
                }
            });


            btnUpdate = findViewById(R.id.btnUpdate);
            btnDeleteAccount = findViewById(R.id.btnDeleteAccount);

            tvProfileUserRole.setText("Logged in as: " + Availablity.currentUser.getRole());
            tvProfileUserName.setText(Availablity.currentUser.getUserName());
            tvProfileEmail.setText(Availablity.currentUser.getEmail());
            tvProfileFullName.setText(Availablity.currentUser.getName());
            tvProfileContact.setText(Availablity.currentUser.getPhone());
            tvProfileGender.setText(Availablity.currentUser.getGender());
            tvProfileDateOfBirth.setText(Availablity.currentUser.getDateOfBirth());
            tvProfileAddress.setText(Availablity.currentUser.getAddress());


            cameraPermissions = new String[]{Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE};
            storagePermissions = new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE};

//        firebaseAuth = FirebaseAuth.getInstance();
            pDialog = new ProgressDialog(this);
            pDialog.setTitle("Please Wait...");
            pDialog.setCanceledOnTouchOutside(false);

            imageView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    showImagePickDialog();

                }
            });


            tvProfileGender.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    final CharSequence[] gender = {"Male", "Female"};
                    AlertDialog.Builder alert = new AlertDialog.Builder(Profile.this);
                    alert.setTitle("Select Gender");
                    alert.setSingleChoiceItems(gender, -1, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            if (gender[which] == "Male") {
                                tvProfileGender.setText("Male");
                            } else if (gender[which] == "Female") {
                                tvProfileGender.setText("Female");
                            }
                        }
                    });
                    alert.show();
                }
            });

            final Calendar myCalendar = Calendar.getInstance();
            final DatePickerDialog.OnDateSetListener date = new DatePickerDialog.OnDateSetListener() {

                @Override
                public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                    myCalendar.set(Calendar.YEAR, year);
                    myCalendar.set(Calendar.MONTH, month);
                    myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);

                    String myFormat = "dd/MM/yy"; //In which you need put here
                    SimpleDateFormat sdf = new SimpleDateFormat(myFormat);

                    tvProfileDateOfBirth.setText(sdf.format(myCalendar.getTime()));
                }
            };

            tvProfileDateOfBirth.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    new DatePickerDialog(Profile.this, date, myCalendar
                            .get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
                            myCalendar.get(Calendar.DAY_OF_MONTH)).show();
                }
            });

            btnUpdate.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    userDatabase.addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                            Map<String, Object> userChildUpdates = new HashMap<>();
                            userChildUpdates.put("address", tvProfileAddress.getText().toString().trim());
                            userChildUpdates.put("name", tvProfileFullName.getText().toString().trim());
                            userChildUpdates.put("email", tvProfileEmail.getText().toString().trim());
                            userChildUpdates.put("gender", tvProfileGender.getText().toString().trim());
                            userChildUpdates.put("phone", tvProfileContact.getText().toString().trim());
                            userChildUpdates.put("dateOfBirth", tvProfileDateOfBirth.getText().toString().trim());

                            userDatabase.child(Availablity.currentUser.getUserName()).updateChildren(userChildUpdates).addOnSuccessListener(new OnSuccessListener<Void>() {
                                @Override
                                public void onSuccess(Void aVoid) {
                                    Toast.makeText(Profile.this, "User Profile Updated", Toast.LENGTH_SHORT).show();
                                }
                            }).addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    Toast.makeText(Profile.this, "Profile upload failed", Toast.LENGTH_SHORT).show();
                                }
                            });


                            new AlertDialog.Builder(Profile.this)
                                    .setTitle("Success")
                                    .setIcon(R.drawable.ic_done_black_24dp)
                                    .setMessage("Updated successfully!")
                                    .show();
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {

                        }
                    });
                }
            });

            btnDeleteAccount.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    new AlertDialog.Builder(Profile.this)
                            .setTitle("Warning")
                            .setMessage("Do you really want to Delete?\n" +
                                    "Your ads will be also deleted.")
                            .setIcon(android.R.drawable.ic_dialog_alert)
                            .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {

                                public void onClick(DialogInterface dialog, int whichButton) {

                                    Query rentsQuery = rentDatabase.orderByChild("userName").equalTo(Availablity.currentUser.getUserName());
                                    Query usersQuery = userDatabase.child(Availablity.currentUser.getUserName());

                                    rentsQuery.addListenerForSingleValueEvent(new ValueEventListener() {
                                        @Override
                                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                            for (DataSnapshot rentSnapshot : dataSnapshot.getChildren()) {
                                                rentSnapshot.getRef().removeValue();
                                            }
                                        }

                                        @Override
                                        public void onCancelled(@NonNull DatabaseError databaseError) {

                                        }
                                    });

                                    usersQuery.addListenerForSingleValueEvent(new ValueEventListener() {
                                        @Override
                                        public void onDataChange(DataSnapshot dataSnapshot) {
                                            for (DataSnapshot userSnapshot : dataSnapshot.getChildren()) {
                                                userSnapshot.getRef().removeValue();
                                            }
                                            new AlertDialog.Builder(Profile.this)
                                                    .setTitle("Success")
                                                    .setMessage("Your account has deleted!")
                                                    .show();
                                            Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                                            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                                            startActivity(intent);
//                                        startActivity(new Intent(Profile.this, MainActivity.class));
//                                        Toast.makeText(Profile.this, "Your account has deleted!", Toast.LENGTH_SHORT).show();
                                        }

                                        @Override
                                        public void onCancelled(DatabaseError databaseError) {
                                            Log.e("Tag", "onCancelled", databaseError.toException());
                                        }
                                    });
                                }
                            })
                            .setNegativeButton(android.R.string.no, null).show();
                }
            });
        }


    }




    private void showImagePickDialog () {
        String[] options = {"Camera", "Gallery"};
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Pick the Image")
                .setItems(options, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        if (i == 0) {
                            //camera clicked
                            if (checkCameraPermission()) {
                                //permission allowed
                                pickFromCamera();
                            } else {
                                //not allowed
                                requestCameraPermission();
                            }
                        } else {
                            //gallery clicked
                            if (checkStoragePermission()) {
                                //permission allowed
                                pickFromGallery();

                            } else {
                                //not allowed
                                requestStoragePermission();
                            }
                        }
                    }
                })
                .show();
    }

    private void pickFromGallery () {
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType("image/*");
        startActivityForResult(intent, IMAGE_PICK_GALLERY_CODE);
    }
    private void pickFromCamera () {
        ContentValues contentValues = new ContentValues();
        contentValues.put(MediaStore.Images.Media.TITLE, "Temp_Image Title");
        contentValues.put(MediaStore.Images.Media.DESCRIPTION, "Temp_Image Description");
        image_uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues);
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        intent.putExtra(MediaStore.EXTRA_OUTPUT, image_uri);
        startActivityForResult(intent, IMAGE_PICK_CAMERA_CODE);
    }
    private boolean checkCameraPermission () {
        boolean result = ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) ==
                (PackageManager.PERMISSION_GRANTED);
        boolean result1 = ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) ==
                (PackageManager.PERMISSION_GRANTED);
        return result && result1;
    }
    private boolean checkStoragePermission () {
        boolean result = ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) ==
                (PackageManager.PERMISSION_GRANTED);
        return result;
    }
    private void requestStoragePermission () {
        ActivityCompat.requestPermissions(this, storagePermissions, STORAGE_REQUEST_CODE);
    }

    private void requestCameraPermission () {
        ActivityCompat.requestPermissions(this, cameraPermissions, CAMERA_REQUEST_CODE);
    }
    @Override
    public void onRequestPermissionsResult ( int requestCode, @NonNull String[] permissions,
                                             @NonNull int[] grantResults){
        switch (requestCode) {
            case CAMERA_REQUEST_CODE: {
                if (grantResults.length > 0) {
                    boolean cameraAccepted = grantResults[0] == PackageManager.PERMISSION_GRANTED;
                    boolean storageAccepted = grantResults[1] == PackageManager.PERMISSION_GRANTED;
                    if (cameraAccepted && storageAccepted) {
                        pickFromCamera();
                    } else {
                        Toast.makeText(this, "Camera Permission is Needed....", Toast.LENGTH_LONG).show();
                    }
                }
            }
            break;
            case STORAGE_REQUEST_CODE: {
                if (grantResults.length > 0) {
                    boolean storageAccepted = grantResults[0] == PackageManager.PERMISSION_GRANTED;
                    if (storageAccepted) {
                        pickFromGallery();
                    } else {
                        Toast.makeText(this, "Storage Permission Needed....", Toast.LENGTH_LONG).show();
                    }
                }
            }
            break;
        }

        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }

    @Override
    protected void onActivityResult ( int requestCode, int resultCode, @Nullable Intent data){

        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            if (requestCode == IMAGE_PICK_GALLERY_CODE) {
                image_uri = data.getData();
                imageView.setImageURI(image_uri);
            } else if (requestCode == IMAGE_PICK_CAMERA_CODE) {
//                image_uri = data.getData();
                imageView.setImageURI(image_uri);
            }
        }
        if (image_uri != null) {
            StorageReference storageReference = FirebaseStorage.getInstance().getReference(Availablity.currentUser.getUserName());
//                    if(image_uri!=null){
            storageReference.putFile(image_uri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                @Override
                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                    Toast.makeText(Profile.this, "Picture uploaded successfully", Toast.LENGTH_SHORT).show();
                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    Toast.makeText(Profile.this, "Picture upload failed", Toast.LENGTH_SHORT).show();
                }
            });
        }

    }




}