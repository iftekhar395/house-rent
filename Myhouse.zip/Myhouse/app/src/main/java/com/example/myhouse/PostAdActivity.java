package com.example.myhouse;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.myhouse.firebase.FirebaseHandler;
import com.example.myhouse.model.Rent;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.annotations.Nullable;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;
public class PostAdActivity extends AppCompatActivity {

    private EditText etTitle;
    private EditText etLocation;
    private EditText etRentFee;
    private Spinner spinnerPeriod;
    private EditText etAddress;
    private EditText etDescription;
    private EditText etNumOfBeds;
    private EditText etNumOfBaths, etNumOfToilets, etNumOfBalconies;
    private EditText etContactName;
    private EditText etContactNumber;
    private EditText etContactEmail;
    private Button btnPost;
    private ImageView ivMyPostImage;
    private static final int CAMERA_REQUEST_CODE = 200;
    private static final int STORAGE_REQUEST_CODE = 300;
    private static final int IMAGE_PICK_GALLERY_CODE = 400;
    private static final int IMAGE_PICK_CAMERA_CODE = 500;
    private String[] cameraPermissions;
    private String[] storagePermissions;
    private Uri image_uri;

    private String RENT_TABLE = "Rent";
    private String USER_TABLE = "User";

    DatabaseReference rentDatabase;
    DatabaseReference userDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post_ad);

        rentDatabase = new FirebaseHandler().getFirebaseConnection(RENT_TABLE);
        userDatabase = new FirebaseHandler().getFirebaseConnection(USER_TABLE);

        etTitle = findViewById(R.id.etTitle);
        etLocation = findViewById(R.id.etLocation);
        etRentFee = findViewById(R.id.etRentFee);
        spinnerPeriod = findViewById(R.id.spinnerPeriod);
        etAddress = findViewById(R.id.etAddress);
        etDescription = findViewById(R.id.etDescription);
        etNumOfBeds = findViewById(R.id.etNumOfBeds);
        etNumOfBaths = findViewById(R.id.etNumOfBaths);

        etNumOfToilets = findViewById(R.id.etNumOfToilets);
        etNumOfBalconies = findViewById(R.id.etNumOfBalconies);
        etContactName = findViewById(R.id.etContactName);
        etContactNumber = findViewById(R.id.etContactNumber);
        etContactEmail = findViewById(R.id.etContactEmail);
        btnPost = findViewById(R.id.btnPost);
        ivMyPostImage = findViewById(R.id.ivMyPostImage);

        ivMyPostImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showImagePickDialog();;
            }
        });

        if (Availablity.currentUser.getName().equals("")) {
            etContactName.setEnabled(true);
        } else {
            etContactName.setText(Availablity.currentUser.getName());
            etContactName.setEnabled(false);
        }
        etContactEmail.setText(Availablity.currentUser.getEmail());
        etContactEmail.setEnabled(false);

        btnPost.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {



                final String adTitle = etTitle.getText().toString().trim();
                final String adLocation = etLocation.getText().toString().trim();
                final String rentFee = etRentFee.getText().toString().trim();
                final String periodOfTime;
                if (spinnerPeriod.getSelectedItem().toString().equals("Monthly")) {
                    periodOfTime = "month";
                } else {
                    periodOfTime = "year";
                }
                final String address = etAddress.getText().toString().trim();
                final String description = etDescription.getText().toString().trim();
                final String beds = etNumOfBeds.getText().toString().trim();
                final String baths = etNumOfBaths.getText().toString().trim();
                final String toilets = etNumOfToilets.getText().toString().trim();
                final String balconies = etNumOfBalconies.getText().toString().trim();
                final String userName = Availablity.currentUser.getUserName();
                final String contactName = etContactName.getText().toString().trim();
                String contactNumber = etContactNumber.getText().toString().trim();
                String contactEmail = etContactEmail.getText().toString().trim();
//                String imageUrl = ivMyPostImage.getTransitionName();
//                Log.e("ivMyPostImage : ",imageUrl);

                Calendar calendar = Calendar.getInstance();
//                SimpleDateFormat mdformat = new SimpleDateFormat("HH:mm:ss");
                SimpleDateFormat mdformat = new SimpleDateFormat();
                final String strDate = mdformat.format(calendar.getTime());

                if (adTitle.equals("") || adLocation.equals("") || rentFee.equals("") || address.equals("") ||
                        description.equals("") || beds.equals("") || baths.equals("") || toilets.equals("") || balconies.equals("") || contactName.equals("") ||
                        contactNumber.equals("")) {
                    Toast.makeText(PostAdActivity.this, "Fill up all fields!", Toast.LENGTH_SHORT).show();
                } else {
//                    userDatabase.child(userName).updateChildren();
                    if (Availablity.currentUser.getName().equals("")) {
                        userDatabase.addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
//                                User user = new User(contactName);
//                                Map<String, Object> userValues = user.toMap();

                                Map<String, Object> userChildUpdates = new HashMap<>();
//                                childUpdates.put("/User/" + userName, userValues);
                                userChildUpdates.put("name", contactName);

                                userDatabase.child(userName).updateChildren(userChildUpdates);
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {

                            }
                        });

                    }

                    final String id = rentDatabase.push().getKey();

                    if (image_uri != null) {
                        StorageReference storageReference = FirebaseStorage.getInstance().getReference("house_image/"+id);
//                    if(image_uri!=null){
                        storageReference.putFile(image_uri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                            @Override
                            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                                Toast.makeText(PostAdActivity.this, "Picture uploaded successfully", Toast.LENGTH_SHORT).show();
                            }
                        }).addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Toast.makeText(PostAdActivity.this, "Picture upload failed", Toast.LENGTH_SHORT).show();
                            }
                        });
                    }else{
                        Toast.makeText(PostAdActivity.this, "Pls, select a picture...", Toast.LENGTH_SHORT).show();
                    }

                    Rent rent = new Rent(adTitle, adLocation, address, rentFee, periodOfTime, description, Integer.parseInt(beds), Integer.parseInt(baths),Integer.parseInt(toilets), Integer.parseInt(balconies), userName, contactNumber, strDate, id);
                    rentDatabase.child(id).setValue(rent);
                    new AlertDialog.Builder(PostAdActivity.this).setMessage("Your ad has posted!").show();
//                    Toast.makeText(PostAdActivity.this, "Your ad has posted!", Toast.LENGTH_SHORT).show();
                }

            }
        });
    }
    private void showImagePickDialog () {
        String[] options = {"Camera", "Gallery"};
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Pick the Image")
                .setItems(options, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        if (i == 0) {
                            //camera clicked
                            if (checkCameraPermission()) {
                                //permission allowed
                                pickFromCamera();
                            } else {
                                //not allowed
                                requestCameraPermission();
                            }
                        } else {
                            //gallery clicked
                            if (checkStoragePermission()) {
                                //permission allowed
                                pickFromGallery();

                            } else {
                                //not allowed
                                requestStoragePermission();
                            }
                        }
                    }
                })
                .show();
    }
    private void pickFromGallery () {
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType("image/*");
        startActivityForResult(intent, IMAGE_PICK_GALLERY_CODE);
    }
    private void pickFromCamera () {
        ContentValues contentValues = new ContentValues();
        contentValues.put(MediaStore.Images.Media.TITLE, "Temp_Image Title");
        contentValues.put(MediaStore.Images.Media.DESCRIPTION, "Temp_Image Description");
        image_uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues);
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        intent.putExtra(MediaStore.EXTRA_OUTPUT, image_uri);
        startActivityForResult(intent, IMAGE_PICK_CAMERA_CODE);
    }
    private boolean checkCameraPermission () {
        boolean result = ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) ==
                (PackageManager.PERMISSION_GRANTED);
        boolean result1 = ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) ==
                (PackageManager.PERMISSION_GRANTED);
        return result && result1;
    }
    private boolean checkStoragePermission () {
        boolean result = ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) ==
                (PackageManager.PERMISSION_GRANTED);
        return result;
    }
    private void requestStoragePermission () {
        ActivityCompat.requestPermissions(this, storagePermissions, STORAGE_REQUEST_CODE);
    }

    private void requestCameraPermission () {
        ActivityCompat.requestPermissions(this, cameraPermissions, CAMERA_REQUEST_CODE);
    }
    @Override
    public void onRequestPermissionsResult ( int requestCode, @NonNull String[] permissions,
                                             @NonNull int[] grantResults){
        switch (requestCode) {
            case CAMERA_REQUEST_CODE: {
                if (grantResults.length > 0) {
                    boolean cameraAccepted = grantResults[0] == PackageManager.PERMISSION_GRANTED;
                    boolean storageAccepted = grantResults[1] == PackageManager.PERMISSION_GRANTED;
                    if (cameraAccepted && storageAccepted) {
                        pickFromCamera();
                    } else {
                        Toast.makeText(this, "Camera Permission is Needed....", Toast.LENGTH_LONG).show();
                    }
                }
            }
            break;
            case STORAGE_REQUEST_CODE: {
                if (grantResults.length > 0) {
                    boolean storageAccepted = grantResults[0] == PackageManager.PERMISSION_GRANTED;
                    if (storageAccepted) {
                        pickFromGallery();
                    } else {
                        Toast.makeText(this, "Storage Permission Needed....", Toast.LENGTH_LONG).show();
                    }
                }
            }
            break;
        }

        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }

    @Override
    protected void onActivityResult ( int requestCode, int resultCode, @Nullable Intent data){

        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            if (requestCode == IMAGE_PICK_GALLERY_CODE) {
                image_uri = data.getData();
                ivMyPostImage.setImageURI(image_uri);
            } else if (requestCode == IMAGE_PICK_CAMERA_CODE) {
//                image_uri = data.getData();
                ivMyPostImage.setImageURI(image_uri);
            }
        }
//        if (image_uri != null) {
//            StorageReference storageReference = FirebaseStorage.getInstance().getReference(Availablity.currentRent.getKey());
////                    if(image_uri!=null){
//            storageReference.putFile(image_uri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
//                @Override
//                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
//                    Toast.makeText(PostAdActivity.this, "Picture uploaded successfully", Toast.LENGTH_SHORT).show();
//                    Uri downloadUrl = taskSnapshot.getUploadSessionUri();
//                    String ImageURL = downloadUrl.toString();
//                    Log.e("Image Url :", ImageURL);
////                    ivMyPostImage.setText(ImageURL);
//                }
//            }).addOnFailureListener(new OnFailureListener() {
//                @Override
//                public void onFailure(@NonNull Exception e) {
//                    Toast.makeText(PostAdActivity.this, "Picture upload failed", Toast.LENGTH_SHORT).show();
//                }
//            });
//        }

    }




}