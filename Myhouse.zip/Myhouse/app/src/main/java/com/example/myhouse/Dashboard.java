package com.example.myhouse;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.Menu;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.myhouse.firebase.FirebaseHandler;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.squareup.picasso.Picasso;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.core.view.GravityCompat;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class Dashboard extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    private ImageView ivDisplayPicture;
    private ImageView ivHeaderDisplayPicture;
    private TextView tvWelcomeUser;
    private TextView tvHeaderUserName;
    private TextView tvHeaderEmail, tvHeaderContact, tvHeaderBirthdate, tvHeaderAddress;

    private TextView tvTotalAds;
    private TextView tvTotalUsers;

    private String USER_TABLE = "User";
    private String RENT_TABLE = "Rent";

    private DatabaseReference userDatabase;
    private DatabaseReference rentDatabase;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        userDatabase = new FirebaseHandler().getFirebaseConnection(USER_TABLE);
        rentDatabase = new FirebaseHandler().getFirebaseConnection(RENT_TABLE);

        ivDisplayPicture = findViewById(R.id.ivDisplayPicture);
        tvWelcomeUser = findViewById(R.id.tvWelcomeUser);

        tvTotalAds = findViewById(R.id.tvTotalAds);
        tvTotalUsers = findViewById(R.id.tvTotalUsers);


        StorageReference storageReference = FirebaseStorage.getInstance().getReference(Availablity.currentUser.getUserName());
        if(storageReference != null){
            storageReference.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                @Override
                public void onSuccess(Uri uri) {
                    Picasso.get().load(uri).into(ivDisplayPicture);
                    Picasso.get().load(uri).into(ivHeaderDisplayPicture);
                }
            });

        }else{
            Toast.makeText(Dashboard.this,"You do not submit your profile photo yet...",Toast.LENGTH_LONG).show();
        }



        try {
            if (Availablity.currentUser.getRole().equals("Renter")) {
                NavigationView navigationView = findViewById(R.id.nav_view);
                navigationView.getMenu().findItem(R.id.itemAddRent).setVisible(false);
                navigationView.getMenu().findItem(R.id.itemMyPosts).setVisible(false);
            } else if (Availablity.currentUser.getRole().equals("Owner")) {
                NavigationView navigationView = findViewById(R.id.nav_view);
                navigationView.getMenu().findItem(R.id.itemAddRent).setVisible(true);
                navigationView.getMenu().findItem(R.id.itemMyPosts).setVisible(true);
            }

            AlertDialog.Builder alert = new AlertDialog.Builder(Dashboard.this);
            alert.setTitle("Welcome");
            alert.setMessage("" + Availablity.currentUser.getName());
            alert.show();
            tvWelcomeUser.setText("Welcome " + Availablity.currentUser.getName());

            Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
            setSupportActionBar(toolbar);

            DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
            ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                    this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
            drawer.addDrawerListener(toggle);
            toggle.syncState();

            NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
            navigationView.setNavigationItemSelectedListener(this);

            View headerView = navigationView.getHeaderView(0);
            ivHeaderDisplayPicture = headerView.findViewById(R.id.ivHeaderDisplayPicture);
            tvHeaderUserName = headerView.findViewById(R.id.tvHeaderUserName);
            tvHeaderEmail = headerView.findViewById(R.id.tvHeaderEmail);
            tvHeaderContact = headerView.findViewById(R.id.tvHeaderContact);
            tvHeaderBirthdate = headerView.findViewById(R.id.tvHeaderBirthdate);
            tvHeaderAddress = headerView.findViewById(R.id.tvHeaderAddress);

            tvHeaderUserName.setText(Availablity.currentUser.getName());
            tvHeaderEmail.setText(Availablity.currentUser.getEmail());
            tvHeaderContact.setText(Availablity.currentUser.getPhone());
            tvHeaderBirthdate.setText(Availablity.currentUser.getDateOfBirth());
            tvHeaderAddress.setText(Availablity.currentUser.getAddress());
        } catch (NullPointerException ignored) {
            startActivity(new Intent(Dashboard.this, MainActivity.class));
        }

        userDatabase.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                long count = dataSnapshot.getChildrenCount();

                if (count == 0) {
                    tvTotalUsers.setText(count + "\nUsers");
                } else if (count > 500) {
                    tvTotalUsers.setText(500 + "+\nUsers");
                } else {
                    tvTotalUsers.setText(count + "\nUsers");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        rentDatabase.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                long count = dataSnapshot.getChildrenCount();

                if (count == 0) {
                    tvTotalAds.setText(count + "\nAds");
                } else if (count > 500) {
                    tvTotalAds.setText(500 + "+\nAds");
                } else {
                    tvTotalAds.setText(count + "\nAds");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    @Override
    public void onBackPressed(){
        AlertDialog.Builder adb;
        adb = new AlertDialog.Builder(Dashboard.this);
        adb.setTitle("Exit Alert");
        adb.setMessage("Do u want to exit?");
        adb.setCancelable(false);
        adb.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                finish();
                Intent intent = new Intent(Dashboard.this, Login.class);
                startActivity(intent);
            }
        });
        adb.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.cancel();
            }
        });
        AlertDialog ad = adb.create();
        ad.show();

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.dashboard, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.menuAbout) {
            AlertDialog aboutme = new AlertDialog.Builder(Dashboard.this)
                    .setTitle("ABOUT APP")
                    .setIcon(android.R.drawable.ic_menu_agenda)
                    .setMessage("Need a house?\n" +
                            "Then, this app is only for you.\n" +
                            "Choose your desired house here.")
                    .show();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.itemHome) {
            Intent homeIntent = new Intent(Dashboard.this, HomeActivity.class);
            startActivity(homeIntent);
        } else if(id == R.id.itemAddRent) {
            Intent postAdIntent = new Intent(Dashboard.this, PostAdActivity.class);
            startActivity(postAdIntent);
        } else if (id == R.id.itemMyPosts) {
            Intent myPostIntent = new Intent(Dashboard.this, MyPosts.class);
            startActivity(myPostIntent);
        } else if (id == R.id.itemProfile) {
            Intent profileIntent = new Intent(Dashboard.this, Profile.class);
            startActivity(profileIntent);
        } else if (id == R.id.itemSignOut) {
            super.onBackPressed();
            Intent loginIntent = new Intent(getApplicationContext(), MainActivity.class);
            loginIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(loginIntent);
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
}