package com.example.myhouse;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    ImageView iv;
    TextView textView, textView1, textView2;
    Animation top,bottom;
    private static int SPLASH_SCREEN=2500;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_main);

        iv = findViewById(R.id.imageView);
        textView = findViewById(R.id.tv);
        textView1 = findViewById(R.id.tv1);
        textView2 = findViewById(R.id.tv2);


//        textView1.setTypeface(tf);
//        textView2.setTypeface(tf);

        top = AnimationUtils.loadAnimation(this,R.anim.top);
        bottom = AnimationUtils.loadAnimation(this,R.anim.bottom);
//        Typeface tf = Typeface.createFromAsset(getAssets(),"font/alexbrush_regular.ttf");
//        textView.setTypeface(tf);
        iv.setAnimation(top);
        textView.setAnimation(bottom);
        textView1.setAnimation(bottom);
        textView2.setAnimation(bottom);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent = new Intent(MainActivity.this, Login.class);
                startActivity(intent);
                finish();
            }
        },SPLASH_SCREEN);
    }
}